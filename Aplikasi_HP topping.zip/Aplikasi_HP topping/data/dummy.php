<?php
 $datahp=
 [
    ["Iphome 11","Warna Hijau - Memory 128 GB","iphone11.jpeg","7125000"],
    ["Iphone 13","Warna Pink - Memory GB 128 GB","iphone13.jpeg","101250000"],
    ["Iphone 12 Pro","Warna Black - Memory 256 GB","iphone12pro.jpeg","14500000"],
    ["Iphone 14","Warna Grey - Memory 512 GB","iphone14.jpeg","15125000"],
   ];

?>