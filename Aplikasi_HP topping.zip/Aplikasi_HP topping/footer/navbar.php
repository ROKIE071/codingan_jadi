
<nav class="navbar navbar-expand" style="background-color: #D4AF37; height: 80px;">
    <div class="container">
     
        <div class="navbar-nav">
          <a class="nav-link font-monospace " style="color: white; margin-right: 20px;" href="home.php">Home</a>
          <a class="nav-link font-monospace " style="color: white; margin-left: 20px;" href="#properti">Transaksi</a>
        </div>

        <div class="navbar-nav ms-auto">
          <a class="nav-link font-monospace " style="color: white;" href="../index.php">Logout</a>
        </div>
      </div>
   
  </nav>
