<!doctype html>
<html lang="en">
  <head>
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body style="background-color: white;">

  <!-- NAVBAR -->
   <?php
        include "footer/navbar.php";//<!-- include fungsinya merequest yang sudah dibikin di footer -->
   ?>

   <div class="container my-4">
        <div class="row">

            <div class="col-lg-6 font-monospace " style="color: black;">
                <h3>Selamat Datang Di<br>Toko Iphone Store</h3>
                <p>tersedia berbagai tipe merek handphone</p>
                <a href="#properti" class="btn btn-info rounded rounded-5">Cari</a>
            </div>

            <div class="col-lg-6">
                <img src="images/Banner.jpeg" alt="IMG" width="300px" height="250px">
            </div>

        </div>
   </div>

   <hr>
   <section id="properti" class="">
        <div class="container my-3 font-monospace">
            <h4 class="alert text-center rounded rounded-5" style="background-color: #D4AF37; color: white;">Daftar Jenis Iphone</h4>

            <div class="row">



                <?php
                // <!--  require fungsinya merequest yang sudah di bikin di data dummy -->
                    require "data/dummy.php";
                    // as artinya (sebagai) 
                    foreach($datahp as $index => $tampil) {
                // isi nya di pecah menjadi 3 bagian
                // perulangan foreach array
                //<!-- foreach perulangan --> 
                    ?> 

                <div class="col-md-3 col-sm-12">
                    <div class="card rounded rounded-5 text-center">

                    <!-- <?= $tampil[3] ?> untuk menampilkan kolom pada bagian harga [3]-->
                        <div class="card-body alert rounded rounded-5 " style="background-color: white;">
                            <img src="images/<?=$tampil[2]?>" alt="IMG" class="card-img-top rounded rounded-5" height="200px">
                            <h5><?=$tampil[0]?></h5>
                            <h5><?=$tampil[1]?></h5>
                            <p><?=$tampil[3]?></p>
                            
                        </div>
                        
                        <div class="card-footer alert">
                           
                        <!--   // href="Transaction_Page.php?index" untuk menampilkan kolom card -->
                            <a href="transaksi.php?index=<?=$index ?>" class="btn btn-info w-100 rounded rounded-5 ">Pilih Iphone</a>
                        
                        </div>
                        
                    </div>
                </div>
                <!-- menutup dari foreach/endforeach -->
                <?php } ?>
            </div>

        </div>
   </section>
   <?php
//    <!-- include fungsinya merequest yang sudah dibikin di footer -->
        include "footer/footer.php";
   ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>
