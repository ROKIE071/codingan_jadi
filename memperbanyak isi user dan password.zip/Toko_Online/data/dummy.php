<?php
 $dataperawatan=
 [
    ["Perawatan 1","Memutihkan kulit dengan form formula perawatan kulit untuk wajah","125000","perawatan1.jpeg"],
    ["Perawatan 2","Menyuntikkan obat bius","125000","perawatan2.jpeg"],
    ["Perawatan 3","Menembakkan laser untuk pemutihan wajah atau menghilangkan komedo dan jerawat","125000","perawatan3.jpeg"],
    ["Perawatan 4","Melapisi kulit yang sudah di tembak laser dengan sabun khusus","125000","perawatan4.jpeg"],
 ];

?>