<!doctype html>
<html lang="en">
  <head>
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body style="background-color: white;">

  <!-- NAVBAR -->
   <?php
        include "footer/navbar.php";//<!-- include mengimpor fungsi-fungsi yang sudah dibikin dari folder footer -->
   ?>

   <div class="container my-4">
        <div class="row">

            <div class="col-lg-6 font-monospace " style="color: black;">
                <h3>Selamat Datang di<br>Toko Perawatan Klinik Kecantikan</h3>
                <p>tersedia berbagai tipe perawatan</p>
                <a href="#properti" class="btn btn-info rounded rounded-5">Cari</a>
            </div>

            <div class="col-lg-6">
                <img src="images/customer.jpeg" alt="IMG" width="300px" height="250px">
            </div>

        </div>
   </div>

   <hr>
   <section id="properti" class="">
        <div class="container my-3 font-monospace">
            <h4 class="alert text-center rounded rounded-5" style="background-color: #964b00; color: white;">Daftar Jenis Perawatan Kulit</h4>

            <div class="row">



                <?php
                // <!--  require untuk mengambil nilai dari data/dummy.php dan di pindahkan ke file home.php -->
                    require "data/dummy.php";
                    foreach($dataperawatan as $index => $tampil) {//perulangan foreach array
                //<!-- foreach perulangan -->
                // <!-- isi dalaman foreach $dataperawatan as=(Sebagai) $index => $tampil untuk mengisi tampilan dalam card--> 
                    ?> 

                <div class="col-md-3 col-sm-12">
                    <div class="card rounded rounded-5 text-center">

                    <!-- <?= $tampil[3] ?> untuk menampilkan nilai dari data yang ke [3] -->
                        <div class="card-body alert rounded rounded-5 " style="background-color: white;">
                            <img src="images/<?=$tampil[3]?>" alt="IMG" class="card-img-top rounded rounded-5" height="200px">
                            <h5><?=$tampil[0]?></h5>
                            <h5><?=$tampil[1]?></h5>
                            <p><?=$tampil[2]?></p>
                            
                        </div>
                        
                        <div class="card-footer alert">
                           
                        <!--   // href="Transaction_Page.php?index" di dapat dari url page home -->
                            <a href="transaksi.php?index=<?=$index ?>" class="btn btn-info w-100 rounded rounded-5 ">Pilih Perawatan Kulit</a>
                        
                        </div>
                        
                    </div>
                </div>
                <!-- menutup dari foreach/endforeach -->
                <?php } ?>
            </div>

        </div>
   </section>
   <?php
//    <!-- include mengimpor fungsi-fungsi yang sudah dibikin dari folder footer -->
        include "footer/footer.php";
   ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>
