<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <title>Halaman Login</title>
    </head>
    <body>
    <div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-5">

            
            <div class="card">
                <div class="card-body">

                    <div class="text-center">
                        <img src="images/logo_kreatif.png" alt="Img" width="200px" height="200px">
                        <h4 class="rounded rounded-5 font-monospace" > SELAMAT DATANG DI CO KREATIF</h4>
                     </div>

                     <!-- method ada 2 yaitu POST DAN GET -->

                     <!-- beda nya dari POST dan GET 

                          kalo POST lebih aman dan tersembunyi untuk mengirimkan data sensitif
                          seperti data pribadi.

                          sedangkan GET untuk mengirimkan data non sensitif
                          seperti: URL link di website  -->
                    <form action="" method="POST">

                        <div class="my-4">
                            <input  type="text" 
                                    class="form-control text-center rounded font-monospace "  
                                    name="user" 
                                    placeholder="Username" 
                                    required>
                        </div>

                        <div class="my-4">
                            <input  type="text"    
                                    class="form-control text-center font-monospace " 
                                    name="pass"    
                                    placeholder="Password" 
                                    required>
                        </div>

                        <div class="">
                            <button type="submit" 
                                    class="btn"
                                    style="background-color: green; color: white;" 
                                    name="login">
                                    Login
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
  </div>


         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    </body>
</html>

<?php
// Isset merupakan untuk melakukan pengecekan terhadap variabel
// $_POST untuk memanggil data yang telah di inputkan agar bisa di tampilkan
// $_POST di dapat dari data yang dikirimkan melalui method HTTP POST yaitu link https dari url nya
if(isset($_POST["login"]))
{
    // $_POST user di dapat dari input name/nama
    $username = $_POST["user"];
    $password = $_POST["pass"];



     /**
         * Meta memberikan infromasi data halaman
         * http-equiv-refresh untuk melakukan memuat ulang halaman web secara otomatis
         * 
         * content=1 nilai dari atribut content
         * url=home.php; sedangkan itu untuk pindah ke halaman home
         *
         * 
         */       
    if($username === "userlsp" && $password === "smkn2bjm" ){
        echo"<meta http-equiv='refresh' content='1;url=home.php'>";
        //  (===) Membandingkan nilai maupun tipe data.
        // contoh: 5 === "5" akan false karena tipe datanya berbeda (integer dan string)

        // (==) Hanya membandingkan nilai, tidak peduli tipe data
        // contoh: 5 == "5" akan true meskipun tipe datanya berbeda (integer dan string)
    }else{
        
        echo
        "
        <script>
            alert('Gagal Login')
        </script>
        ";

    
    }
}

?>