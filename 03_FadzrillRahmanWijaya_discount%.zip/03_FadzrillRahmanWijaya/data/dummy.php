<?php
 $dataproduk=
 [
    ["JaheXpress","Isi deskripsi prduk JaheXpress","3000","Jahe.jpeg"],
    ["Bunga Telang","Isi deskripsi prduk Bunga Telang","5000","Bunga telang.jpeg"],
    ["Lulur Kopi","Isi deskripsi prduk Lulur Kopi","4500","Lulur Kopi.jpeg"],
    ["Lulur intan sari","Isi deskripsi prduk Lulur intan sari","3500","lulur intan.jpeg"],
 ];

?>