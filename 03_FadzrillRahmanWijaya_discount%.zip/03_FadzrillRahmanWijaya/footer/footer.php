<div class="footer footer-expand" style="background-color: green; height:50px; ">
    <div class="text-center font-monospace" style="color: White; padding-top: 15px;">
      &copy; Fadzrill Rahman Wijaya 2024
    </div>
  </div>